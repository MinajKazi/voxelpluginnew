import { defineConfig } from "@fiftyone/plugin-build";

export default defineConfig(__dirname);
